"""Tests for the SGI package."""
